# IPLoop Windows C++ SDK v2.0

**Native C++ SDK for Windows** - Residential proxy network integration with enterprise features.

**Architecture aligned with Android SDK v2.0:** Binary tunnel protocol, production endpoints, optimized connection handling, and enterprise features.

## Features

✅ **Native C++ API** - Modern C++17 with RAII and smart pointers  
✅ **C API compatibility** - Use from C, C#, Python, Delphi, VB6, etc.  
✅ **v2.0 Binary Protocol** - No base64 overhead, optimized throughput  
✅ **Production Endpoints** - Direct connection to 159.65.95.169:9443 (WSS)  
✅ **CONNECT Proxy** - HTTP tunneling via 159.65.95.169:8880  
✅ **Auto-reconnect** - Exponential backoff with never-give-up retry  
✅ **Enterprise proxy features** - Geographic targeting, session management, browser profiles  
✅ **Thread-safe** - Safe to call from multiple threads  
✅ **Advanced bandwidth tracking** - Real-time statistics and node scoring  
✅ **GDPR compliant** - User consent management built-in  
✅ **Connection pooling** - Up to 5 tunnels per node for better performance  

## Quick Start

### CMake Integration

```cmake
find_package(IPLoopSDK REQUIRED)
target_link_libraries(your_app IPLoop::IPLoopSDK)
```

### Basic Usage

```cpp
#include <IPLoop/IPLoopSDK.h>

int main() {
    auto& sdk = IPLoop::SDK::getInstance();
    
    // Initialize
    sdk.initialize("your_api_key");
    sdk.setUserConsent(true);
    
    // Start
    sdk.start([](bool success, const std::string& message) {
        if (success) {
            std::cout << "HTTP Proxy: " << IPLoop::SDK::getInstance().getHttpProxyUrl() << std::endl;
        }
    });
    
    // Use proxy URLs in your application (v2.0 production endpoints)
    // HTTP: http://user:auth@159.65.95.169:8880
    // SOCKS5: socks5://user:auth@159.65.95.169:1080
    
    return 0;
}
```

## Enterprise Features

### Geographic Targeting

```cpp
auto config = IPLoop::ProxyConfig::createDefault()
    .setCountry("US")           // Target US proxies
    .setCity("miami")           // Specifically Miami
    .setASN(15169);             // Target specific ISP

sdk.setProxyConfig(config);
```

### Session Management

```cpp
auto config = IPLoop::ProxyConfig::createDefault()
    .setSessionType("sticky")   // sticky, rotating, per-request
    .setLifetime(60)            // 60 minute sessions
    .setRotateMode("time")      // Auto-rotate every interval
    .setRotateInterval(10);     // 10 minutes

sdk.setProxyConfig(config);
```

### Browser Profiles

```cpp
auto config = IPLoop::ProxyConfig::createDefault()
    .setProfile("chrome-win")   // chrome-win, firefox-mac, mobile-ios
    .setUserAgent("custom UA")  // Custom User-Agent
    .setMinSpeed(100)           // Minimum 100 Mbps
    .setMaxLatency(100);        // Maximum 100ms latency

sdk.setProxyConfig(config);
```

## Advanced Usage

### Comprehensive Monitoring

```cpp
// Status changes
sdk.setStatusCallback([](IPLoop::SDKStatus old, IPLoop::SDKStatus current) {
    std::cout << "Status: " << static_cast<int>(old) << " -> " << static_cast<int>(current) << std::endl;
});

// Bandwidth monitoring  
sdk.setBandwidthCallback([](const IPLoop::BandwidthStats& stats) {
    std::cout << "Bandwidth: " << stats.totalMB << " MB, " 
              << stats.totalRequests << " requests" << std::endl;
});

// Error handling
sdk.setErrorCallback([](const IPLoop::ErrorInfo& error) {
    std::cerr << "Error: " << error.message << " (Code: " << error.code << ")" << std::endl;
});
```

### Custom Proxy Auth Generation

```cpp
// Generate auth string with specific configuration
auto customConfig = IPLoop::ProxyConfig::createDefault()
    .setCountry("DE")
    .setCity("berlin") 
    .setSessionId("my-session-123");

std::string authString = sdk.generateProxyAuth(&customConfig);
// Result: "apikey-country-DE-city-berlin-session-my-session-123"

// Use in external HTTP client
std::string proxyUrl = "http://user:" + authString + "@127.0.0.1:7777";
```

## C API Usage

Perfect for integration with other languages:

```c
#include "IPLoop_C_API.h"

int main() {
    // Initialize
    IPLoop_Initialize("your_api_key");
    IPLoop_SetConsent(1);
    
    // Configure
    IPLoop_SetCountry("US");
    IPLoop_SetCity("miami");
    
    // Start
    if (IPLoop_Start() == 0) {
        printf("Proxy URL: %s\\n", IPLoop_GetProxyURL());
        
        // Monitor
        while (IPLoop_IsActive()) {
            printf("Requests: %d, Bandwidth: %.2f MB\\n", 
                   IPLoop_GetTotalRequests(), IPLoop_GetTotalMB());
            Sleep(1000);
        }
    }
    
    IPLoop_Stop();
    return 0;
}
```

## Integration Examples

### cURL with IPLoop

```cpp
CURL *curl = curl_easy_init();
curl_easy_setopt(curl, CURLOPT_PROXY, sdk.getHttpProxyUrl().c_str());
curl_easy_setopt(curl, CURLOPT_URL, "https://httpbin.org/ip");
curl_easy_perform(curl);
curl_easy_cleanup(curl);
```

### Windows HTTP Services (WinHTTP)

```cpp
HINTERNET hSession = WinHttpOpen(L"MyApp/1.0", WINHTTP_ACCESS_TYPE_NAMED_PROXY,
    L"127.0.0.1:7777", NULL, 0);

// Set proxy auth
std::wstring proxyAuth = L"user:" + Utils::stringToWString(sdk.generateProxyAuth());
WinHttpSetOption(hSession, WINHTTP_OPTION_PROXY_USERNAME, 
    (LPVOID)L"user", sizeof(L"user"));
WinHttpSetOption(hSession, WINHTTP_OPTION_PROXY_PASSWORD,
    (LPVOID)proxyAuth.c_str(), proxyAuth.length() * sizeof(wchar_t));
```

### Python Integration

```python
import ctypes

# Load DLL
iploop = ctypes.CDLL('./IPLoopSDK.dll')

# Initialize
iploop.IPLoop_Initialize(b"your_api_key")
iploop.IPLoop_SetConsent(1)
iploop.IPLoop_Start()

# Get proxy URL
get_url = iploop.IPLoop_GetProxyURL
get_url.restype = ctypes.c_char_p
proxy_url = get_url().decode('utf-8')

# Use with requests
import requests
response = requests.get("https://httpbin.org/ip", proxies={"http": proxy_url})
print(response.json())
```

## Build Instructions

### Requirements

- **Windows 10/11** (primary target)
- **Visual Studio 2019+** or **MinGW-w64**
- **CMake 3.16+**
- **C++17 compiler**

### Building

```bash
git clone <iploop-repo>
cd iploop-platform/sdk/windows-cpp

# Create build directory
mkdir build && cd build

# Configure (Visual Studio)
cmake .. -G "Visual Studio 16 2019" -A x64

# Or configure (MinGW)
cmake .. -G "MinGW Makefiles"

# Build
cmake --build . --config Release

# Install (optional)
cmake --install . --prefix ./install
```

### Build Options

```bash
# Static library instead of DLL
cmake .. -DBUILD_SHARED_LIBS=OFF

# Skip examples
cmake .. -DBUILD_EXAMPLES=OFF

# Debug build
cmake .. -DCMAKE_BUILD_TYPE=Debug
```

## Distribution

After building, you'll have:

```
build/
├── bin/
│   ├── IPLoopSDK.dll           # Main DLL
│   └── examples/               # Example executables
├── lib/
│   ├── IPLoopSDK.lib          # Import library
│   └── cmake/IPLoopSDK/       # CMake config files
└── include/
    └── IPLoop/                # Headers
        ├── IPLoopSDK.h
        ├── Types.h
        ├── ProxyConfig.h
        └── Callbacks.h
```

## v2.0 Improvements

🚀 **Binary Protocol**: No more base64 encoding overhead - direct binary tunneling  
🚀 **Production Endpoints**: Direct connection to production gateway (159.65.95.169)  
🚀 **CONNECT Proxy**: HTTP tunneling via port 8880 for better compatibility  
🚀 **Connection Pooling**: Up to 5 tunnels per node for optimal performance  
🚀 **Node Scoring**: Smart node selection based on performance metrics  
🚀 **Never-Give-Up Reconnect**: 10-minute intervals after fast reconnect attempts  

## Architecture

Mirrors the Android SDK v2.0 architecture:

```
┌─────────────────┐    ┌──────────────────┐    ┌─────────────────┐
│   Application   │    │   IPLoop SDK     │    │  IPLoop Server  │
│                 │    │                  │    │                 │
│ ┌─────────────┐ │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ │HTTP Client  │◄┼────┤►│ProxyManager  │ │    │ │Registration │ │
│ │(cURL, etc.) │ │    │ │              │ │    │ │Service      │ │
│ └─────────────┘ │    │ └──────────────┘ │    │ └─────────────┘ │
│                 │    │ ┌──────────────┐ │    │ ┌─────────────┐ │
│ ┌─────────────┐ │    │ │WebSocket     │◄┼────┤►│Gateway      │ │
│ │Status/Stats │◄┼────┤►│Client        │ │    │ │Service      │ │
│ │Callbacks    │ │    │ │              │ │    │ └─────────────┘ │
│ └─────────────┘ │    │ └──────────────┘ │    └─────────────────┘
└─────────────────┘    │ ┌──────────────┐ │
                       │ │TunnelManager │ │
                       │ │              │ │
                       │ └──────────────┘ │
                       └──────────────────┘
```

**Key Components:**
- **WebSocketClient**: Auto-reconnecting WebSocket with exponential backoff
- **TunnelManager**: Handles proxy tunnels and traffic routing  
- **BandwidthTracker**: Real-time statistics collection
- **ProxyConfig**: Enterprise feature configuration
- **DeviceInfo**: System information gathering

## API Reference

### Core Classes

| Class | Description |
|-------|-------------|
| `SDK` | Main singleton SDK class |
| `ProxyConfig` | Advanced proxy configuration |
| `BandwidthStats` | Statistics and monitoring data |
| `ErrorInfo` | Error information structure |

### SDK Methods

| Method | Description |
|--------|-------------|
| `initialize(apiKey)` | Initialize SDK with API key |
| `start(callback)` | Start proxy service |
| `stop(callback)` | Stop proxy service |
| `setUserConsent(bool)` | Set GDPR consent |
| `getStats()` | Get bandwidth statistics |
| `setProxyConfig(config)` | Set enterprise proxy settings |
| `generateProxyAuth(config)` | Generate proxy auth string |

### Status Values

```cpp
enum class SDKStatus {
    IDLE = 0,           // Not initialized  
    INITIALIZING = 1,   // Initialization in progress
    CONNECTING = 2,     // Connecting to server
    CONNECTED = 3,      // Connected and active
    RECONNECTING = 4,   // Attempting to reconnect
    STOPPING = 5,       // Shutdown in progress
    STOPPED = 6,        // Completely stopped
    ERROR = 7           // Error state
};
```

## Troubleshooting

### Common Issues

**Build Errors:**
- Ensure C++17 support: `/std:c++17` (MSVC) or `-std=c++17` (GCC)
- Link against required libraries: `ws2_32.lib wininet.lib crypt32.lib`

**Runtime Errors:**
- **"SDK not initialized"**: Call `initialize()` before `start()`
- **"User consent required"**: Call `setUserConsent(true)` 
- **Connection failures**: Check firewall, antivirus, and internet connectivity

**Performance Issues:**
- Use Release build for production
- Enable compiler optimizations
- Consider static linking to reduce DLL overhead

### Debug Logging

```cpp
// Enable debug logging
sdk.setLoggingEnabled(true);

// Custom log handler
Logger::getInstance().setCallback([](LogLevel level, const std::string& tag, const std::string& msg) {
    std::cout << "[" << static_cast<int>(level) << "] " << tag << ": " << msg << std::endl;
});
```

## Support

- **Email**: support@iploop.io  
- **Docs**: https://docs.iploop.io
- **GitHub**: https://github.com/iploop/windows-cpp-sdk

---

## ✅ v2.0 SDK Complete!

**Perfect alignment with Android SDK v2.0** - Same binary protocol, same production endpoints, same enterprise features.

**🎯 What's Different from v1.0.63:**
- **Binary Protocol**: No base64 encoding overhead
- **Production Endpoints**: wss://159.65.95.169:9443/ws + 159.65.95.169:8880 proxy
- **Connection Pooling**: Up to 5 tunnels per node
- **Node Scoring**: Smart node selection based on performance
- **Never-Give-Up Reconnect**: 10-minute intervals after exhausting fast attempts
- **Enhanced Statistics**: Advanced bandwidth tracking with throughput metrics

**🚀 Ready for Mike** - Complete C++ SDK matching your v2.0 production architecture!