#include "internal/Utils.h"
#include <chrono>
#include <sstream>
#include <fstream>
#include <random>

#ifdef _WIN32
#include <windows.h>
#include <winsock2.h>
#include <iphlpapi.h>
#include <shlobj.h>
#pragma comment(lib, "iphlpapi.lib")
#pragma comment(lib, "shell32.lib")
#endif

namespace IPLoop {
namespace Utils {

uint64_t getCurrentTimestamp() {
    auto now = std::chrono::system_clock::now();
    auto duration = now.time_since_epoch();
    return std::chrono::duration_cast<std::chrono::milliseconds>(duration).count();
}

std::string getCurrentTimeString() {
    auto now = std::chrono::system_clock::now();
    auto time_t = std::chrono::system_clock::to_time_t(now);
    
    std::stringstream ss;
    ss << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S");
    return ss.str();
}

std::string generateUUID() {
    // Simple UUID v4 generation
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<uint32_t> dis(0, 0xFFFFFFFF);
    
    uint32_t data[4];
    for (int i = 0; i < 4; ++i) {
        data[i] = dis(gen);
    }
    
    // Set version (4) and variant bits
    data[1] = (data[1] & 0x0FFFFFFF) | 0x40000000;
    data[2] = (data[2] & 0x3FFFFFFF) | 0x80000000;
    
    char uuid[37];
    sprintf_s(uuid, sizeof(uuid), 
        "%08x-%04x-%04x-%04x-%04x%08x",
        data[0], 
        (data[1] >> 16) & 0xFFFF, 
        data[1] & 0xFFFF,
        (data[2] >> 16) & 0xFFFF, 
        data[2] & 0xFFFF, 
        data[3]);
    
    return std::string(uuid);
}

std::string sha256(const std::string& input) {
    // Simplified hash function (not cryptographically secure)
    // In production, would use a proper crypto library
    std::hash<std::string> hasher;
    size_t hash = hasher(input);
    
    std::stringstream ss;
    ss << std::hex << hash;
    return ss.str();
}

std::string trim(const std::string& input) {
    size_t first = input.find_first_not_of(' ');
    if (first == std::string::npos) return "";
    
    size_t last = input.find_last_not_of(' ');
    return input.substr(first, (last - first + 1));
}

#ifdef _WIN32
std::string getOSVersion() {
    OSVERSIONINFOW osvi;
    ZeroMemory(&osvi, sizeof(OSVERSIONINFOW));
    osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOW);
    
    // Note: GetVersionEx is deprecated but used for simplicity
    #pragma warning(push)
    #pragma warning(disable: 4996)
    if (GetVersionExW(&osvi)) {
        std::stringstream ss;
        ss << "Windows " << osvi.dwMajorVersion << "." << osvi.dwMinorVersion 
           << " Build " << osvi.dwBuildNumber;
        return ss.str();
    }
    #pragma warning(pop)
    
    return "Windows (unknown version)";
}

std::string getArchitecture() {
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    
    switch (si.wProcessorArchitecture) {
        case PROCESSOR_ARCHITECTURE_AMD64: return "x64";
        case PROCESSOR_ARCHITECTURE_INTEL: return "x86";
        case PROCESSOR_ARCHITECTURE_ARM64: return "arm64";
        case PROCESSOR_ARCHITECTURE_ARM: return "arm";
        default: return "unknown";
    }
}

uint32_t getCPUCores() {
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    return static_cast<uint32_t>(si.dwNumberOfProcessors);
}

uint32_t getAvailableMemoryMB() {
    MEMORYSTATUSEX memInfo;
    memInfo.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memInfo);
    return static_cast<uint32_t>(memInfo.ullAvailPhys / (1024 * 1024));
}

std::string getHostname() {
    char hostname[256];
    if (gethostname(hostname, sizeof(hostname)) == 0) {
        return std::string(hostname);
    }
    return "unknown";
}

std::string getLocalIP() {
    // Simplified - get first non-loopback IPv4 address
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        return "127.0.0.1";
    }
    
    char hostname[256];
    if (gethostname(hostname, sizeof(hostname)) == 0) {
        struct hostent* host = gethostbyname(hostname);
        if (host && host->h_addr_list[0]) {
            struct in_addr addr;
            memcpy(&addr, host->h_addr_list[0], sizeof(struct in_addr));
            std::string ip = inet_ntoa(addr);
            WSACleanup();
            return ip;
        }
    }
    
    WSACleanup();
    return "127.0.0.1";
}

std::string getMACAddress() {
    // Get first adapter MAC address
    IP_ADAPTER_ADDRESSES* pAddresses = nullptr;
    ULONG outBufLen = 0;
    
    // Get buffer size needed
    GetAdaptersAddresses(AF_UNSPEC, 0, nullptr, pAddresses, &outBufLen);
    
    pAddresses = (IP_ADAPTER_ADDRESSES*)malloc(outBufLen);
    if (!pAddresses) return "00:00:00:00:00:00";
    
    DWORD result = GetAdaptersAddresses(AF_UNSPEC, 0, nullptr, pAddresses, &outBufLen);
    
    std::string macAddress = "00:00:00:00:00:00";
    
    if (result == NO_ERROR) {
        IP_ADAPTER_ADDRESSES* pCurrentAddresses = pAddresses;
        while (pCurrentAddresses) {
            if (pCurrentAddresses->PhysicalAddressLength == 6) {
                char mac[18];
                sprintf_s(mac, sizeof(mac), "%02X:%02X:%02X:%02X:%02X:%02X",
                    pCurrentAddresses->PhysicalAddress[0],
                    pCurrentAddresses->PhysicalAddress[1],
                    pCurrentAddresses->PhysicalAddress[2],
                    pCurrentAddresses->PhysicalAddress[3],
                    pCurrentAddresses->PhysicalAddress[4],
                    pCurrentAddresses->PhysicalAddress[5]);
                macAddress = std::string(mac);
                break;
            }
            pCurrentAddresses = pCurrentAddresses->Next;
        }
    }
    
    free(pAddresses);
    return macAddress;
}

std::string getAppDataPath() {
    char path[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathA(nullptr, CSIDL_APPDATA, nullptr, 0, path))) {
        return std::string(path);
    }
    return "C:\\Users\\Default\\AppData\\Roaming";
}

std::wstring stringToWString(const std::string& str) {
    if (str.empty()) return std::wstring();
    
    int size_needed = MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), NULL, 0);
    std::wstring wstrTo(size_needed, 0);
    MultiByteToWideChar(CP_UTF8, 0, &str[0], (int)str.size(), &wstrTo[0], size_needed);
    return wstrTo;
}

std::string wstringToString(const std::wstring& wstr) {
    if (wstr.empty()) return std::string();
    
    int size_needed = WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), NULL, 0, NULL, NULL);
    std::string strTo(size_needed, 0);
    WideCharToMultiByte(CP_UTF8, 0, &wstr[0], (int)wstr.size(), &strTo[0], size_needed, NULL, NULL);
    return strTo;
}

#else
// Non-Windows implementations (stubs)
std::string getOSVersion() { return "Unknown OS"; }
std::string getArchitecture() { return "unknown"; }
uint32_t getCPUCores() { return 1; }
uint32_t getAvailableMemoryMB() { return 1024; }
std::string getHostname() { return "unknown"; }
std::string getLocalIP() { return "127.0.0.1"; }
std::string getMACAddress() { return "00:00:00:00:00:00"; }
std::string getAppDataPath() { return "/tmp"; }
std::wstring stringToWString(const std::string& str) { return std::wstring(str.begin(), str.end()); }
std::string wstringToString(const std::wstring& wstr) { return std::string(wstr.begin(), wstr.end()); }
#endif

bool fileExists(const std::string& path) {
    std::ifstream file(path);
    return file.good();
}

std::string readFile(const std::string& path) {
    std::ifstream file(path);
    if (!file.is_open()) return "";
    
    std::stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

bool writeFile(const std::string& path, const std::string& content) {
    // Create directory if it doesn't exist
    size_t lastSlash = path.find_last_of("\\/");
    if (lastSlash != std::string::npos) {
        std::string dir = path.substr(0, lastSlash);
        #ifdef _WIN32
        CreateDirectoryA(dir.c_str(), nullptr);
        #endif
    }
    
    std::ofstream file(path);
    if (!file.is_open()) return false;
    
    file << content;
    return file.good();
}

// v2.0: Binary protocol utilities (simplified implementations)
std::vector<uint8_t> packBinaryMessage(const std::string& type, const std::vector<uint8_t>& payload) {
    std::vector<uint8_t> message;
    
    // Simple binary format: [type_length][type][payload_length][payload]
    uint32_t typeLen = static_cast<uint32_t>(type.length());
    uint32_t payloadLen = static_cast<uint32_t>(payload.size());
    
    // Add type length (4 bytes)
    message.insert(message.end(), (uint8_t*)&typeLen, (uint8_t*)&typeLen + 4);
    
    // Add type string
    message.insert(message.end(), type.begin(), type.end());
    
    // Add payload length (4 bytes)
    message.insert(message.end(), (uint8_t*)&payloadLen, (uint8_t*)&payloadLen + 4);
    
    // Add payload
    message.insert(message.end(), payload.begin(), payload.end());
    
    return message;
}

std::pair<std::string, std::vector<uint8_t>> unpackBinaryMessage(const std::vector<uint8_t>& data) {
    if (data.size() < 8) {
        return {"", {}};
    }
    
    // Extract type length
    uint32_t typeLen = *reinterpret_cast<const uint32_t*>(data.data());
    
    if (data.size() < 8 + typeLen) {
        return {"", {}};
    }
    
    // Extract type
    std::string type(data.begin() + 4, data.begin() + 4 + typeLen);
    
    // Extract payload length
    uint32_t payloadLen = *reinterpret_cast<const uint32_t*>(data.data() + 4 + typeLen);
    
    if (data.size() < 8 + typeLen + payloadLen) {
        return {"", {}};
    }
    
    // Extract payload
    std::vector<uint8_t> payload(data.begin() + 8 + typeLen, data.begin() + 8 + typeLen + payloadLen);
    
    return {type, payload};
}

uint32_t calculateCRC32(const std::vector<uint8_t>& data) {
    // Simplified CRC32 (not a proper implementation)
    uint32_t crc = 0xFFFFFFFF;
    for (uint8_t byte : data) {
        crc ^= byte;
        for (int i = 0; i < 8; i++) {
            crc = (crc >> 1) ^ (0xEDB88320 & (-(crc & 1)));
        }
    }
    return ~crc;
}

bool validateBinaryMessage(const std::vector<uint8_t>& data) {
    // Basic validation
    return data.size() >= 8;  // Minimum header size
}

} // namespace Utils
} // namespace IPLoop