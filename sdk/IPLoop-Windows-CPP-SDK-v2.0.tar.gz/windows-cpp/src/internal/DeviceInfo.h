#pragma once

#include "../include/IPLoop/Types.h"
#include <string>
#include <memory>

namespace IPLoop {

/**
 * Device information gathering for v2.0 registration
 * Provides system details needed by IPLoop servers
 */
class DeviceInfo {
public:
    DeviceInfo();
    ~DeviceInfo();
    
    /**
     * Gather current device information
     */
    IPLoop::DeviceInfo gather() const;
    
    /**
     * Generate unique device ID based on hardware
     */
    std::string generateDeviceId() const;
    
    /**
     * Get cached device ID (persistent across app restarts)
     */
    std::string getCachedDeviceId() const;
    
private:
    class Impl;
    std::unique_ptr<Impl> pImpl;
};